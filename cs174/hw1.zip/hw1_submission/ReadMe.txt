Assignment 1, NAME: Hee Hwang, UID: 804212513

Here is the list of interaction that I implemented:
  Press q, 'Q', ESC to leave

Requirements 1, 2, 3, and 4 are all implemented.

