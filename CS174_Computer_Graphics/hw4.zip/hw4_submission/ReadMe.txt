Assignment 4, NAME: Hee Hwang, UID: 804212513

Here is the list of interaction that I implemented:

  Press 'i', 'I' to go forward.
  Press 'o', 'O' to go backward.


Requirements 1, 2, 3, 4, 5, 6, and 7 are all implemented.

Left Object(cube)
- Texture coordinate range from [0,1]
- Tri-linear filtering

Right Object(crate)
- Texture coordinate range from [-0.5,1.5]
- Nearest neighbor filtering
