Assignment 3, NAME: Hee Hwang, UID: 804212513

Here is the list of interaction that I implemented:

  Press 'q', 'Q' to leave
  Press "up and down arrow" to change the altitude of the camera.
  Press "left and right arrow" to control the heading of the camera.
  Press 'i', 'I' to go forward.
  Press 'j', 'J' to go left.
  Press 'k', 'K' to go right.
  Press 'm', 'M' to go backward.
  Press 'r', 'R' to reset the view back to the start position.

  callbackReshape function maintains the ratio of horizontal and vertical view.

  
Early Submission (5/7 Tuesday 10:50 PM) : +20 Points
  
Requirements 1, 2, 4, and 6 are all implemented.
Extra Credit 1 is implemented.

Requirements 3, 5, 7, and Extra credit 2 have not been implemented.

