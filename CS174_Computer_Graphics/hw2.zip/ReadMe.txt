Assignment 2, NAME: Hee Hwang, UID: 804212513

Here is the list of interaction that I implemented:

  Press 'q', 'Q' to leave
  Press 'c', 'C' to cycle the color of all cubes on each key press.
  Press "up and down arrow" to change the altitude of the camera.
  Press "left and right arrow" to control the heading of the camera.
  Press 'i', 'I' to go forward.
  Press 'j', 'J' to go left.
  Press 'k', 'K' to go right.
  Press 'm', 'M' to go backward.
  Press 'r', 'R' to reset the view back to the start position.
  Press 'n', 'N' to make horizontal field of view narrower.
  Press 'w', 'W' to make horizontal field of view wider.


Requirements 1, 2, 3, 4, and 5 are all implemented except cross hair.

